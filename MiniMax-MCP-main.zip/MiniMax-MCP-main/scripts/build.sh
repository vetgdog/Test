#!/bin/bash
rm -rf dist/ build/ *.egg-info/
uv build